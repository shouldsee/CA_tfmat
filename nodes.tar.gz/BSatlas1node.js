var nodes=[ 
{id:1, value:100, label:'6152',color:'orange'}, 
];
var edges=[ 
];
var BSatlas1node = { nodes:nodes,edges:edges};